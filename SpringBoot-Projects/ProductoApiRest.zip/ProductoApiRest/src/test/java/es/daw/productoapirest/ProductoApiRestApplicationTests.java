package es.daw.productoapirest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductoApiRestApplicationTests {

    @Test
    void contextLoads() {
    }

}
