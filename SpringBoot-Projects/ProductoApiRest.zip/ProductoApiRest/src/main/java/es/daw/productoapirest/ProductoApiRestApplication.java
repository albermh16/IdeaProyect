
package es.daw.productoapirest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductoApiRestApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProductoApiRestApplication.class, args);
    }

}
