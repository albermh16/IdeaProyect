package es.daw.hotelesapi.mapper;

import es.daw.hotelesapi.dto.HabitacionRequestDTO;
import es.daw.hotelesapi.entity.Habitacion;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface HabitacionMapper {

//    HabitacionRequestDTO toDTO(Habitacion entity);
//
//    Habitacion toEntity(HabitacionRequestDTO dto);
//
//    List<HabitacionRequestDTO> toDTOs(List<Habitacion> entities);
//    List<Habitacion> toEntitys(List<HabitacionRequestDTO> dtos);
}
