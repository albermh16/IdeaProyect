package es.daw.hotelesapi.controllers;

import es.daw.hotelesapi.dto.HotelResponseDTO;
import es.daw.hotelesapi.repository.HotelRepository;
import es.daw.hotelesapi.service.HotelService;
import lombok.AllArgsConstructor;
import org.mapstruct.Mapping;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/hoteles")
public class HotelController {
    private final HotelService hotelService;

    @GetMapping("/buscar")
    public ResponseEntity<List<HotelResponseDTO>> findHotel(@RequestParam(required = false) String localidad,
                                                            @RequestParam(required = false) String codigoCategoria){
        return ResponseEntity.ok(hotelService.buscarHoteles(localidad, codigoCategoria));

    }
}
