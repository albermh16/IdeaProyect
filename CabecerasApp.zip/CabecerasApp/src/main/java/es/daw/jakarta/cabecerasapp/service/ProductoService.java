package es.daw.jakarta.cabecerasapp.service;

import es.daw.jakarta.cabecerasapp.model.Producto;

import java.util.List;

public interface ProductoService {
    List<Producto> listar();
}
