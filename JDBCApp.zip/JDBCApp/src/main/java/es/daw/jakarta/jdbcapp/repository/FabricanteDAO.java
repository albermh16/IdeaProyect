package es.daw.jakarta.jdbcapp.repository;

public class FabricanteDAO {

    
}
